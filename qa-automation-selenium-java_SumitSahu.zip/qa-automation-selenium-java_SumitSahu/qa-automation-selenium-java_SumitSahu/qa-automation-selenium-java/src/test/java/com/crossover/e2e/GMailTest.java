package com.crossover.e2e;

import java.io.File;
import java.io.FileReader;
import java.util.List;
import java.util.Properties;
import junit.framework.TestCase;
import org.junit.Test;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class GMailTest extends TestCase {
    private WebDriver driver;
    private Properties properties = new Properties();

    public void setUp() throws Exception {
        
        properties.load(new FileReader(new File("src/test/resources/test.properties")));
        //Dont Change below line. Set this value in test.properties file incase you need to change it..
        System.setProperty("webdriver.chrome.driver",properties.getProperty("webdriver.chrome.driver") );
        driver = new ChromeDriver();
    }

    public void tearDown() throws Exception {
        driver.quit();
    }

    /*
     * Please focus on completing the task
     * 
     */
    @Test
    public void testSendEmail() throws Exception {
    	WebDriverWait wait = new WebDriverWait (driver, 20);
    	
    	driver.manage().window().maximize();
    	
        driver.get("https://mail.google.com/");
       
        Thread.sleep(5000);
        
        WebElement userElement = driver.findElement(By.id("identifierId"));
        userElement.sendKeys(properties.getProperty("username"));

        driver.findElement(By.id("identifierNext")).click();

        Thread.sleep(5000);

        WebElement passwordElement = driver.findElement(By.name("password"));
        passwordElement.sendKeys(properties.getProperty("password"));
        driver.findElement(By.xpath("//*[@class='RveJvd snByac' and contains(text(),'Next')]")).click();

        Thread.sleep(10000);

        
        WebElement composeElement = driver.findElement(By.xpath("//*[@role='button' and contains(text(),'Compose')]"));
        wait.until(ExpectedConditions.visibilityOf(composeElement));
        composeElement.click();

        driver.findElement(By.xpath("//textarea[@name='to']")).clear();
        driver.findElement(By.xpath("//textarea[@name='to']")).sendKeys(String.format("%s@gmail.com", properties.getProperty("username")));

        // emailSubject and emailbody to be used in this unit test.
        String emailSubject = properties.getProperty("email.subject");
        String emailBody = properties.getProperty("email.body"); 
        
        driver.findElement(By.xpath("//input[@name='subjectbox']")).sendKeys(emailSubject);
        driver.findElement(By.xpath("//*[@class='Am Al editable LW-avf tS-tW']")).sendKeys(emailBody);
                
        driver.findElement(By.xpath("//*[@role='button' and text()='Send']")).click();
                
        
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(),'Message sent')]")));                                                   
        List<WebElement> inboxEmails = wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath("//*[@class='zA zE']"))));                   
        List<WebElement> starOptions = driver.findElements(By.xpath("//span[@class='aXw T-KT']"));
        
        for(WebElement email : inboxEmails){                                                                                                                           
            if(email.isDisplayed() && email.getText().contains("email.subject")){ 
            	
            	starOptions.get(1).click();
            	
            	Thread.sleep(3000);
            	
                email.click();
                
                Thread.sleep(4000);
                                    

                WebElement label = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(@title,'with label Social')]")));                    
                WebElement subject = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[contains(text(),'CrossOver Test Email Subject')]")));          
                WebElement body = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'CrossOver Test Email Body; This test sends and opens the email')]")));   

            }                                                                                                                                                          
        }  
        
        
        
    }
}
